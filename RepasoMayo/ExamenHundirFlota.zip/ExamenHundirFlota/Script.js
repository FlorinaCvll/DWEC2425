function ocultarMonigote() {
    /*let monigoteMostrar = document.getElementById("mostrar");*/
    let monigoteMostrarSRC = document.getElementById("mostrar").getAttribute("src");
    // console.log(monigoteMostrarSRC);

    if (monigoteMostrarSRC == "imagenes/mostrar.png") {
        // console.log(monigoteMostrarSRC);
        document.getElementById("mostrar").setAttribute("src", "imagenes/ocultar.png");
        ocultarImagenes();
    } else if (monigoteMostrarSRC == "imagenes/ocultar.png") {
        // console.log(monigoteMostrarSRC);
        document.getElementById("mostrar").setAttribute("src", "imagenes/mostrar.png");
        mostrarImagenes();
    } else {
        console.log("Error");
    }

}


function ocultarImagenes() {
    let imagenes = document.getElementsByClassName("img");
    for (let i = 0; i < imagenes.length; i++) {
        imagenes[i].style.visibility = "hidden";
    }

}
function mostrarImagenes() {
    let imagenes = document.getElementsByClassName("img");;
    for (let i = 0; i < imagenes.length; i++) {
        imagenes[i].style.visibility = "visible";
    }
}


window.onload = function () {
    document.getElementById("mostrar").addEventListener("click", ocultarMonigote);
    colocarImagenes();
}