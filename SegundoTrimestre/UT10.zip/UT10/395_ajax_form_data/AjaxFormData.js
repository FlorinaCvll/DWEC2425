function ajaxFormData() {

}

window.onload = function () {
    document.getElementById("ajaxFormData").addEventListener("click", ajaxFormData);
}